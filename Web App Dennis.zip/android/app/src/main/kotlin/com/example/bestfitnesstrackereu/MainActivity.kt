package com.example.bestfitnesstrackereu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
