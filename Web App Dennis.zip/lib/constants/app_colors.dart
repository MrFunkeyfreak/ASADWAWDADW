import 'package:flutter/material.dart';

//custom Color - get used for design
const Color primaryColor = Color.fromARGB(255, 31, 229, 146);
